/** This class serves as the driver of the game. */
public class AnimalChess {

	public static void main(String[] args) {
		View view = new View();
		Controller controller = new Controller(view);
	}
}