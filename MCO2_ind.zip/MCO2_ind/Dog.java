/** This class represents the Dog piece of the game. */
public class Dog extends Piece{

  /** This constructor initializes the rank, color, and initial row and column

      @param color the color of the Dog piece
      @param r the row the dog is in
      @param c the column the dog is in
  */
	public Dog (String color, int r, int c) {
		super("DOG", 4, color, r, c);
	}

  /** This method checks if the dog can jump across water

      @param r the row of the destination
      @param c the column of the destination
      @param b board of the game

      @return true if dog piece can jump across water, otherwise returns false
  */
	public boolean canJumpWater(int r, int c, Board b){
		return false;
	}
	
  /** This method checks if dog can walk on water
    
      @param r the row of the destination
      @param c the column of the destination
      @param b board of the game
      
      @return true if dog piece can walk on water, otherwise returns false
  */
	public boolean canWalkWater(int r, int c, Board b) {
		return false;
	}

  /** This method checks if the dog can capture a piece
  
      @param r row the piece to be checked
      @param c the column of the piece to be checked
      @param b the board the game is on

      @return true if dog piece can capture an opponent piece, otherwise returns false
  */
	public boolean canCapture(int r, int c, Board b){
		Piece animal = b.getSpace(r, c).getPiece();
		
		if (b.isTrap(r, c)) { // opponent animal is at a trap
			if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
				if (COLOR.equalsIgnoreCase(b.trapColor(r, c))) // opponent animal is at player's trap
					return true;
				else // opponent animal is at own trap
					return false;
			}
			return false;
		}
		else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank())  // not in a trap
			return true;
		return false;
	}
	
  /** This method checks if the attempted move of dog is valid
    
      @param r the row destination
      @param c the column destination
      @param b the board of the game
      
      @return true if destination is valid for dog piece, otherwsise returns false 
  */
	public boolean isValidMove(int r, int c, Board b) {
		int rowDistance = Math.abs(r - currR);
		int colDistance = Math.abs(c - currC);
		
		// checks if player is only moving at a distance of 1 space
		if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
			// checks if there is no piece at the destination
			if (b.getSpace(r, c).getPiece() == null) {
				if (b.isWater(r, c))
					return canWalkWater(r, c, b);
				else if (b.isDen(r, c)) {
					if (COLOR.equalsIgnoreCase(b.denColor(c)))
						return false;
					return true;
				}
				return true; // empty space or trap
			}
			else {
				  if (b.isWater(r, c))
					  return canWalkWater(r, c, b);
				  return canCapture(r, c, b);
			}
		}
		return false;
	}
  
}