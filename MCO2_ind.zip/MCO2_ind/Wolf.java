/** This class represents the wolf pieces. */
public class Wolf extends Piece{
  
  /** This constructor initializes the rank, color, and initial row and column
  
      @param Color color of the piece
      @param r the row the piece is in
      @param c the column the player is in
  */
  public Wolf(String Color, int r, int c){
    super("WOLF", 3, Color, r, c);
  }
  
  /** This method checks if the wolf can jump over water
    
      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on
      
      @return true if wolf piece can jump across water, otherwise returns false
  */
  public boolean canJumpWater(int r, int c, Board b){
    return false;
  }
  
  /** This method checks if wolf can walk on water
    
      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on
      
      @return true if wolf piece can walk on water, otherwise returns false
  */
  public boolean canWalkWater(int r, int c, Board b){
    return false;
  }
  
  /** This method checks whether the wolf can capture another piece
  
      @param r the row of the piece to capture
      @param c the column of the piece to capture
      @param b the board the game is on 
      
      @return true if wolf piece can capture opponent piece, otherwise returns false
  */
  public boolean canCapture(int r, int c, Board b){
		Piece animal = b.getSpace(r, c).getPiece();
		
		if (b.isTrap(r, c)) { // opponent animal is at a trap
			if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
				if (COLOR.equalsIgnoreCase(b.trapColor(r, c))) // opponent animal is at player's trap
					return true;
				else // opponent animal is at own trap
					return false;
			}
			return false;
		}
		else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank())  // not in a trap
			return true;
		return false;
  }
  
  /** This method checks if an attempted move is valid 
  
      @param r the row the piece attemps to move to
      @param c the column the piece attempts to move to
      @param b the board the game is on
      
      @return true if destination is valid for wolf piece, otherwise returns false
  */
  public boolean isValidMove(int r, int c, Board b) {
		int rowDistance = Math.abs(r - currR);
		int colDistance = Math.abs(c - currC);
		
		// checks if player is only moving at a distance of 1 space
		if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
			// checks if there is no piece at the destination
			if (b.getSpace(r, c).getPiece() == null) {
				if (b.isWater(r, c))
					return canWalkWater(r, c, b);
				else if (b.isDen(r, c)) {
					if (COLOR.equalsIgnoreCase(b.denColor(c)))
						return false;
					return true;
				}
				return true; // empty space or trap
			}
			else {
				  if (b.isWater(r, c))
					  return canWalkWater(r, c, b);
				  return canCapture(r, c, b);
			}
		}
		return false;
	}

}