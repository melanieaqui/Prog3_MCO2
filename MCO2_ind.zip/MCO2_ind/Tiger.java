/** This class represents the tiger pieces. */
public class Tiger extends Piece{
	
  /** This constructor initializes the rank, color, and initial row and column

      @param color the color of the Lion piece
      @param r row of the Tiger piece
      @param c column of the tiger piece
  */
  public Tiger(String color, int r,int c){
	  super("TIGER", 6, color, r, c);
  }
  
  /** This method checks if the tiger can jump across water

      @param r the row destination
      @param c the column destination
      @param b the board the game is on
      
      @return true if tiger piece can jump across water, otherwise returns false
  */
  public boolean canJumpWater(int r, int c, Board b) {
	  int i = 1;
	  boolean found = false;
		
	  // checks for a mouse on water
	  if (currR == r){ // horizontal jump
		  if (c - currC > 0) {
			  while (i <= 3 && !found) {
				  if (b.getSpace(currR, currC + i).getPiece() != null) // there is a mouse on the way
					  found = true;
				  i++;
			  }
		  }
		  else {
			  i = -1;
			  while (i >= -3 && !found) {
				  if (b.getSpace(currR, currC + i).getPiece() != null) // there is a mouse on the way
					  found = true;
				  i--;
			  }
		  }
	  }
	  else { // vertical jump
		  if (r - currR > 0) {
			  while (i <= 2 && !found) {
				  if (b.getSpace(currR + i, currC).getPiece() != null) // there is a mouse on the way
					  found = true;
				  i++;
			  }
		  }
		  else {
			  i = -1;
			  while (i >= -2 && !found) {
				  if (b.getSpace(currR + i, currC).getPiece() != null) // there is a mouse on the way
					  found = true;
				  i--;
			  }
		  }
	  }
		
	  if (!found) {
		  if (b.getSpace(r, c).getPiece() == null)
			  return true;
		  return canCapture(r, c, b);
	  }
	  return false;
  }
	
  /** This method checks if the tiger can walk on water
  
      @param r the row destination
      @param c the column destination
      @param b the board the game is on
      
      @return true if tiger piece can walk on water, otherwise returns false
  */
  public boolean canWalkWater(int r, int c, Board b) {
	  return false;
  }
	
  /** This method checks if tiger can capture a certain piece
    
      @param r the row of the piece to capture
      @param c the column of the piece to capture
      @param b the board the game is on
      
      @return true if tiger piece can capture opponent piece, otherwise returns false
  */
  public boolean canCapture(int r, int c, Board b){
	  Piece animal = b.getSpace(r, c).getPiece();
		
	  if (b.isTrap(r, c)) { // opponent animal is at a trap
		  if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
			  if (COLOR.equalsIgnoreCase(b.trapColor(r, c))) // opponent animal is at player's trap
				  return true;
			  else // opponent animal is at own trap
					return false;
		  }
		  return false;
	  }
	  else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank())  // not in a trap
		  return true;
	  return false;
  }
	
  /** This method checks if the tiger's attempted move is valid 
    
      @param r the row destination of attempted move
      @param c the column destination of attempted move
      @param b board the game is on
      
      @return true if destination is valid for tiger piece, otherwise returns false
  */
  public boolean isValidMove(int r, int c, Board b) {
	  int rowDistance = Math.abs(r - currR);
	  int colDistance = Math.abs(c - currC);
	  int rowDist = r - currR;
	  int colDist = c - currC;
		
	  // checks if player is only moving at a distance of 1 space
	  if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
		  // checks if there is no piece at the destination
		  if (b.getSpace(r, c).getPiece() == null) {
			  if (b.isWater(r, c))
				  return canWalkWater(r, c, b);
			  else if (b.isDen(r, c)) {
				  if (COLOR.equalsIgnoreCase(b.denColor(c)))
					  return false;
				  return true;
			  }
			  return true; // empty space or trap
		  }
		  else {
			  if (b.isWater(r, c))
				  return canWalkWater(r, c, b);
			  return canCapture(r, c, b);
		  }
	  }
	  // checks if player is jumping across water
	  else if ((rowDistance == 0 && colDistance == 4) || (rowDistance == 3  && colDistance == 0)) {
		  // checks if player's animal is in a space where it can move across the water 
		  if (rowDistance == 0 && colDist > 0 && b.isWater(currR, currC + 1))
			  return canJumpWater(r, c, b);
		  else if (rowDistance == 0 && colDist < 0 && b.isWater(currR, currC - 1))
			  return canJumpWater(r, c, b);
		  else if (colDistance == 0 && rowDist > 0 && b.isWater(currR + 1, currC))
			  return canJumpWater(r, c, b);
		  else if (colDistance == 0 && rowDist < 0 && b.isWater(currR - 1, currC))
			  return canJumpWater(r, c, b);
	  }
	  return false;
  }
   
}