/** This class represents the leopard class. */
public class Leopard extends Piece{
	
  /** This constructor initializes the rank, color, and initial row and column

      @param color the color of the leopard piece
      @param r the current row of the leopard piece
      @param c the current column of the Leopard piece
  */
  public Leopard(String color, int r, int c){
    super ("LEOPARD", 5, color,r, c);
  }

  /** This method checks if leopard can jump across water
  
      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on

      @return true if leopard piece can jump across water, otherwise returns false
  */
  public boolean canJumpWater(int r, int c, Board b){
    return false;
  }
  
  /** This method checks if the leopard can walk on water
  
      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on

      @return true if leopard piece can walk on water, otherwise returns false
  */
  public boolean canWalkWater(int r, int c, Board b){
    return false;
  }
  
  /** This method checks if leopard can capture a piece
    
      @param r the row of the piece to be captured
      @param c the column of the piece to be captured
      @param b the board the game is on

      @return true if leopard piece can capture opponent piece, otherwise returns false
  */
  public boolean canCapture(int r, int c, Board b){
		Piece animal = b.getSpace(r, c).getPiece();
		
		if (b.isTrap(r, c)) { // opponent animal is at a trap
			if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
				if (COLOR.equalsIgnoreCase(b.trapColor(r, c))) // opponent animal is at player's trap
					return true;
				else // opponent animal is at own trap
					return false;
			}
			return false;
		}
		else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank())  // not in a trap
			return true;
		return false;
  }
  
  /** This method checks if leopard's attempted move is valid

      @param r the row of the attempted move
      @param c the column of the attempted move
      @param b the board the game is on
      
      @return true if destination is valid for leopard piece, otherwise returns false
  */
  public boolean isValidMove(int r, int c, Board b) {
		int rowDistance = Math.abs(r - currR);
		int colDistance = Math.abs(c - currC);
		
		// checks if player is only moving at a distance of 1 space
		if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
			// checks if there is no piece at the destination
			if (b.getSpace(r, c).getPiece() == null) {
				if (b.isWater(r, c))
					return canWalkWater(r, c, b);
				else if (b.isDen(r, c)) {
					if (COLOR.equalsIgnoreCase(b.denColor(c)))
						return false;
					return true;
				}
				return true; // empty space or trap
			}
			else {
				  if (b.isWater(r, c))
					  return canWalkWater(r, c, b);
				  return canCapture(r, c, b);
			}
		}
		return false;
	}

}