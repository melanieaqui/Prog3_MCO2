import java.awt.event.*;

/** The controller class implements what happens with each action the player does. */
public class Controller implements ActionListener{
  
  /** This constructor of the controller class

	    @param view the view or GUI of the game
	*/
  public Controller(View view){
    this.view = view;
    board = new Board();
    players = new Player[2];
    bEnd = false;
    
    view.setActionListeners(this);
    
    // pieces are in a "bag," not the chess board
	  piece = new Piece[8];
	  piece[0] = new Mouse(" ", 0, 0);
    piece[1] = new Cat(" ", 0, 0);
    piece[2] = new Wolf(" ", 0, 0);
	  piece[3] = new Dog(" ", 0, 0);
    piece[4] = new Leopard(" ",0,0);
    piece[5] = new Tiger(" ",0, 0);
	  piece[6] = new Lion(" ", 0, 0);
	  piece[7] = new Elephant(" ", 0, 0);
  }

  @Override
  /** This method controls what happens when a button is clicked 

	    @param e represents the the actionEvent of the button clicked on
	*/
  public void actionPerformed(ActionEvent e) {
	  if (e.getActionCommand().equals("Press to pick your animals")) {
		  view.setAnimalLbl(pickStart());
		  view.setAnimalEnabled(false);
		  view.setColorEnabled(true);
	  }
	  else if (e.getActionCommand().equals("RED")) {
		  players[0] = new Player("RED", true);
		  players[1] = new Player("BLUE", false);
		  players[0].savePieces(board);
		  players[1].savePieces(board);
		  view.setColorEnabled(false);
		  view.setTurnLbl("RED");
		  view.setSpaceEnabled(true);
	  }
	  else if (e.getActionCommand().equals("BLUE")) {
		  players[0] = new Player("BLUE", true);
		  players[1] = new Player("RED", false);
		  players[0].savePieces(board);
		  players[1].savePieces(board);
		  view.setColorEnabled(false);
		  view.setTurnLbl("BLUE");
		  view.setSpaceEnabled(true);
	  }
	  else {
		  Object source = e.getSource();
		  
		  for (int i = 0; i < 7; i++) {
			  for (int j = 0; j < 9; j++) {
				  if (source == view.getSpace(i, j) && !bEnd)
					  playClick(i, j);
			  }
		  }
	  }
	
  }

  /** This method randomizes the animals at the start of the game
  
      @return string of the result of the animal picking
  */
  public String pickStart() {
	  int min = 0, max = 7;
	  int i = 0, j = 0;
	  int no;
	  
	  while (i == j) {
			i = (int)Math.floor(Math.random()*(max - min + 1) + min);
			j = (int)Math.floor(Math.random()*(max - min + 1) + min);
	  }
	  
	  if (i > j)
		  no = 1;
	  else
		  no = 2;
	  
	  view.setColorLbl(no);
	  
	  return "Player 1 got " + piece[i].getAnimal() + "!     " + "Player 2 got " + piece[j].getAnimal() + "!";
  }

  /** This method controls the gameplay of the game

	    @param r the row of the button the player clicked
	    @param c the column of the button the player clicked
	*/
  public void playClick(int r, int c) {
	  int toR, toC;
	  int i = 0;
	  
	  // gets current player
	  for (i = 0; i < 2; i++) {
  		if (players[i].getIsTurn())
  			break;
	  }
	  
	  // selecting an animal piece
	  if (select) {
		  from[0] = r;
		  from[1] = c;
		  
		  if (board.getSpace(from[0], from[1]).getPiece() != null) {
			  if (players[i].getColor().equalsIgnoreCase(board.getSpace(from[0], from[1]).getPiece().getColor())) {
				  select = false; // so that next button click will be checked for destination
				  view.setMoveLbl("MAKING A MOVE (" + (board.getSpace(from[0],from[1]).getPiece().getAnimal()).toUpperCase() + ")");
			  }
		  }
	  }
	  // selecting a destination space
	  else if (!select) {
		  toR = r;
		  toC = c;
		  		  
		  // player wants to change animal
		  if (from[0] == toR && from[1] == toC) {
			  select = true;
			  view.setMoveLbl("SELECTING AN ANIMAL");
		  }
		  else if (board.getSpace(from[0], from[1]).getPiece().isValidMove(toR, toC, board)) {
			  board.getSpace(from[0], from[1]).getPiece().move(toR, toC, board); // move animal on board
			  view.moveIcon(from[0], from[1], toR, toC); // move icon on gui
			  updateEnd(toR, toC);
			  updateTurn();
			  select = true; // so that next player can choose their animal
			  
			  view.setMoveLbl("SELECTING AN ANIMAL");
		  }
	  }
	  
	  for (int j = 0; j < 2; j++) {
	  	if (players[j].getIsTurn())
	  		view.setTurnLbl(players[j].getColor());
	  }
	  
	  if (bEnd) {
		  view.setMoveLbl(" ");
	   	view.setResultLbl(winner.getColor());
	   	view.setSpaceEnabled(false);
			view.setTurnLbl(null);
	  }
	}

	/** This method updates the players' turn*/
  public void updateTurn(){
	  if (players[0].getIsTurn()){
	    players[0].setIsTurn(false);
	    players[1].setIsTurn(true);
	  }
	  else{
	    players[1].setIsTurn(false);
	    players[0].setIsTurn(true);
	  }
	}

	/** This method checks if the game already ended and updates winner
  
		  @param row the row the player's last chose piece is on
		  @param col the columns the player's last chosen piece is on
	*/
  public void updateEnd(int row, int col){
	  if (players[0].isWinner(col, row, players[1])){
			winner = players[0];
			bEnd = true;
		}
		else if(players[1].isWinner(col, row, players[0])){
			winner = players[1];
			bEnd = true;
		}
	}
  
	/**the GUI of the game*/
	private View view;
	/**boolean value of whether the game is finished*/
	private boolean bEnd;
	/**the board the game is currently on*/
	private Board board;
	/**represents the players of the game*/
	private Player players[];
	/**represent the winner of the game*/
	private Player winner;
	/**represents the pieces in the bag the player chooses from at the starts*/
	private Piece piece[];
	/**boolean value representing if the player has already chosen an animal*/
	private boolean select = true;
	/**the coordinates of the button that was clicked*/
	private int from[] = new int[2];
	
}