/** This class represents the board of the game. */
public class Board {
	
  /** This constructor instantiates the spaces of the Board. */
	public Board() {
		spaces = new Space[7][9];
		// initialize red pieces
		spaces[0][2] = new Space(new Elephant("red", 0, 2), 0, 2);
		spaces[6][0] = new Space(new Lion("red", 6, 0), 6, 0);
		spaces[5][1] = new Space(new Dog("red", 5, 1), 5, 1);
		spaces[6][2] = new Space(new Mouse("red", 6, 2), 6, 2);
		spaces[0][0] = new Space(new Tiger("red", 0, 0),0, 0);
		spaces[1][1] = new Space(new Cat("red", 1, 1), 1,1);
		spaces[2][2] = new Space(new Wolf("red", 2, 2), 2, 2) ;
		spaces[4][2] = new Space(new Leopard("red", 4, 2), 4, 2);
		
		// initialize blue pieces
		spaces[6][6] = new Space(new Elephant("blue", 6, 6), 6, 6);
		spaces[0][8] = new Space(new Lion("blue", 0, 8), 0, 8);
		spaces[1][7] = new Space(new Dog("blue", 1, 7), 1, 7);
		spaces[0][6] = new Space(new Mouse("blue", 0, 6), 0, 6);
		spaces[6][8] = new Space(new Tiger("blue", 6, 8),6, 8);
		spaces[5][7] = new Space(new Cat("blue", 5, 7), 5, 7);
		spaces[4][6] = new Space(new Wolf("blue", 4, 6), 4, 6);
		spaces[2][6] = new Space(new Leopard("blue", 2, 6), 2, 6);
		
		// initialize terrain spaces
		for (int i = 0; i < 7; i++){
			for (int j = 0; j < 9; j++){
				if (spaces[i][j] == null)
					spaces[i][j] = new Space(null, i, j);
			}
		}
	}

  /** This method returns a space of the Board 
   
      @param r the row of the space
      @param c the column of the space
   
      @return space on the board being asked
  */
	public Space getSpace(int r, int c){
		return spaces[r][c];
	}

	/** This method returns if the entered coordinates is water
    
      @param r row of the space to be checked
      @param c colum of the space to be checked

      @return boolean value on whether the space is water
  */
	public boolean isWater(int r, int c) {
		if ((r == 1 || r == 2 || r == 4 || r == 5) && (c >= 3 && c <= 5))
			return true;
		return false;
	}

	/** This method returns if the entered coordinates is a den
  
      @param r row of the space to be checked
      @param c column of the space to be checked

      @return true if space is a den, otherwise return false
  */
	public boolean isDen(int r, int c) {
		if (r == 3 && (c == 0 || c == 8))
			return true;
		return false;
	}

	/** This method checks is the entered coordinates is a trap
   
      @param r row of the space to be checked
      @param c column of the space to be checked
      
      @return true if space is a trap, otherwise return false
  */
	public boolean isTrap(int r, int c) {
		if ((r == 2 && c == 0) || (r == 2 && c == 8) || (r == 4 && c == 0) || (r == 4 && c == 8))
			return true;
		else if (r == 3 && (c == 1 || c == 7))
			return true;
		return false;
	}

	/** This method returns the color of the den on the board
  
      @param c column of the den

      @return the color of the den
  */
	public String denColor(int c) {
		if (c == 0)
			return "red";
		return "blue";
	}
  
  /** This method returns the color of the trap
    
      @param r row of the trap
      @param c column of the trap

      @return the color of the trap
  */
	public String trapColor (int r, int c) {
		if (c == 0 || c == 1)
			return "red";
		return "blue";
	}
	
	/** 2D array of space of the board */
	private Space[][] spaces;
}