/** This class represents the Elephant pieces. */
public class Elephant extends Piece {

	/** This constructor initializes the rank, color, and initial row and column

      @param color color of the elephant piece
      @param r row of the elephant piece
      @param c column of the elephant piece
  */
	public Elephant (String color, int r, int c) {
		super("ELEPHANT", 8, color, r, c);
	}

	/** This method checks if elephant piece can jump across water
  
      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on

      @return true if elephant piece can jump across water, otherwise returns false
  */
	public boolean canJumpWater(int r, int c, Board b){
		return false;
	}

	/** This method checks if the elephant can walk on water

      @param r the row of the destination
      @param c the column of the destination
      @param b the board the game is on

      @return true if elephant piece can walk on water, otherwise returns false
  */
	public boolean canWalkWater(int r, int c, Board b) {
		return false;
	}
	
  /** This method checks if the elephant can capture a piece
    
      @param r the row the piece to be captured is on
      @param c the column the piece to be captured is on
      @param b the board the game is on

      @return true if elephant piece can capture opponent piece, otherwise returns false
  */
	public boolean canCapture(int r, int c, Board b){
		Piece animal = b.getSpace(r, c).getPiece();
		
		if (b.isTrap(r, c)) { // opponent animal is at a trap
			if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
				if (COLOR.equalsIgnoreCase(b.trapColor(r, c)) && animal.getRank() != 1) // opponent animal is at player's trap
					return true;
				else // opponent animal is at own trap
					return false;
			}
			return false;
		}
		else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank() && animal.getRank() != 1)  // not in a trap
			return true;
		return false;
	}
	
  /** This method checks is the attempted move is valid

      @param r the row of the attempted move
      @param c the column of the attempted move
      @param b the board the game is on
      
      @return true if destination is valid for elephant piece, otherwise returns false
  */
	public boolean isValidMove(int r, int c, Board b) {
		int rowDistance = Math.abs(r - currR);
		int colDistance = Math.abs(c - currC);
		
		// checks if player is only moving at a distance of 1 space
		if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
			// checks if there is no piece at the destination
			if (b.getSpace(r, c).getPiece() == null) {
				if (b.isWater(r, c))
					return canWalkWater(r, c, b);
				else if (b.isDen(r, c)) {
					if (COLOR.equalsIgnoreCase(b.denColor(c)))
						return false;
					return true;
				}
				return true; // empty space or trap
			}
			else {
				  if (b.isWater(r, c))
					  return canWalkWater(r, c, b);
				  return canCapture(r, c, b);
			}
		}
		return false;
	}
	
}
