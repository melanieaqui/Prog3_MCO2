/** This class represents all the individual spaces on the board. */

public class Space {

	/** This constructor initializes the piece that occupies it, and the row and column of the space
  
      @param p is the piece that occupies the space
      @param r the row of the space
      @param c the column of the space
   */
	public Space(Piece p, int r, int c) {
		setPiece(p);
		COLUMN = c;
		ROW = r;
	}

	/** This method gets the row of the space
	  
	    @return the row of the space
	 */
	public int getRow() {
		return ROW;
	}

	/** This method gets the column of the space
	  
	    @return the column of the space
	 */
	public int getColumn() {
		return COLUMN;
	}
  
	/** This method gets the piece that is currently on that space
	  
	    @return returns the Piece object of the space
	 */
	public Piece getPiece() {
		return piece;
	}

  /** This method sets the Piece of the space
   
      @param p piece of the space
   */
	public void setPiece(Piece p){
		piece = p;
	}

  /** The row of the space */
	private final int ROW;
  /** The column of the space */
	private final int COLUMN;
  /** The Piece occupying the space */
	private Piece piece;
}