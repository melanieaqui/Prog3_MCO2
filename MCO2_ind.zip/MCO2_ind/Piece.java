/** This class represents the pieces in the game. */

public abstract class Piece {

  /** This constructor initializes all attributes of the piece
  
      @param a the animal of the piece
      @param r the rank of the piece
      @param c the color of the piece
      @param row the row the piece is on
      @param col the column the piece is on  
  */
	public Piece(String a, int r, String c, int row, int col){
		ANIMAL = a;
		RANK = r;
		COLOR = c;

		currR = row;
		currC = col;
		isCaptured = false;
  }
  
  /** This method is used to get the animal the piece is representing. 
   
      @return string of the animal of the piece
   */
	public String getAnimal() {
		return ANIMAL;
	}
  
  /** This method is used to get the color of the piece. 
  
      @return the color of the piece
   */
	public String getColor(){
		return COLOR;
	}
  
  /** This method gets the rank of the piece. 
   
      @return the rank of the piece
   */
	public int getRank(){
		return RANK;
	}
  
  /** This method returns if the piece has been captured or not. 
   
      @return true if the piece has been captured, otherwise false
   */
	public boolean getIsCaptured() {
		return isCaptured;
	}
  
  /** This method updates isCaptured when the piece has been captured or not.
  
      @param c determines is the piece has been captured
  */
	public void setIsCaptured(boolean c){
		isCaptured = c;
	}

	/** This method moves the piece on the board
   
      @param r row of the destination
      @param c column of the destination
      @param b board the game is on
   */
	public void move(int r, int c, Board b) {
		// no piece at destination space
		if (b.getSpace(r, c).getPiece() == null) {
			// place piece inside space
			b.getSpace(r, c).setPiece(this);
			// set current space's piece as null
			b.getSpace(currR, currC).setPiece(null);
			// update coordinates
			currR = r;
			currC = c;
		}
		else
			capture(r, c, b);
	}

	/** This method captures a piece
  
      @param r the row of the piece to be captured
      @param c the column of the piece to be captured
      @param b the board game is on

  */
	public void capture(int r, int c, Board b) {
		// set opponent piece's isCaptured to true
		b.getSpace(r, c).getPiece().setIsCaptured(true);
		// set the destination space's piece as the current piece
		b.getSpace(r, c).setPiece(this);
		// set current space's piece as null
		b.getSpace(currR, currC).setPiece(null);
		// update coordinates
		currR = r;
		currC = c;
	}

  /** This method tells if the piece has the ability to jump in water

      @param r the destination row
      @param c the destination column
      @param b the board the game is on

      @return true if piece can jump across water, otherwise returns false
  */
	public abstract boolean canJumpWater(int r, int c, Board b);

	/** This method checks if player can walk on water
  
      @param r the row of the destination
      @param c the column of the destination
      @param b board the game is on

      @return true if piece can walk on water, otherwise returns false
  */
	public abstract boolean canWalkWater(int r, int c, Board b);

  /** This method checks if the piece can capture a piece in a destination
    
      @param r the row of the opponent's piece
      @param c the column of the opponent's piece
      @param b board the player 

      @return true if piece can capture a piece, otherwise returns false
  */
	public abstract boolean canCapture(int r, int c, Board b);
  
  /** This method checks if the move is valid for the piece
   
      @param r the row destination the piece wants to go to
      @param c the column destination the piece wants to go to
      @param b the board the game is on

      @return true if destination is valid for piece
  */
  public abstract boolean isValidMove(int r, int c, Board b);

  	
	/** The animal the piece represents */
	private final String ANIMAL;
  /** The rank of the animal the piece represents */
	protected final int RANK;
  /** The color of the pieces */
	protected final String COLOR;
  /** Value of whether the piece has been captured */
	private boolean isCaptured;
  /**Current row of the piece*/
	protected int currR;
  /**Current column of the piece*/
	protected int currC;
}