/** This class represents the cat piece. */
public class Cat extends Piece{
  
  /** This constructor initializes the rank, color, and initial row and column
  
      @param color color of the cat piece
      @param r current row of the cat piece
      @param c current column of the cat piece
  */
  public Cat(String color, int r, int c){
    super ("CAT", 2, color, r, c);
  }

  /**This method checks if the cat can jump across water
  
      @param r row of the destination
      @param c column of the destination
      @param b board of the game

      @return true if cat piece can jump across the water, otherwise returns false
  */
  public boolean canJumpWater(int r, int c, Board b){
		return false;
	}
	
  /** This method checks if the cat can walk on water

      @param r row of the destination
      @param c column of the destination
      @param b board tha game is on

      @return true if cat piece can walk on water, otherwise returns false
  */
	public boolean canWalkWater(int r, int c, Board b) {
		return false;
	}

  /** This method checks if the cat can capture the piece in the board

      @param r row of the destination where a piece is
      @param c column of the destination where a piece is
      @param b board where the game is on

      @return true if cat piece can capture an opponent piece, otherwise return false
  */
	public boolean canCapture(int r, int c, Board b){
		Piece animal = b.getSpace(r, c).getPiece();
		
		if (b.isTrap(r, c)) { // opponent animal is at a trap
			if (COLOR.equalsIgnoreCase(animal.getColor()) == false) {
				if (COLOR.equalsIgnoreCase(b.trapColor(r, c))) // opponent animal is at player's trap
					return true;
				else // opponent animal is at own trap
					return false;
			}
			return false;
		}
		else if (COLOR.equalsIgnoreCase(animal.getColor()) == false && RANK >= animal.getRank())  // not in a trap
			return true;
		return false;
	}

	/** This method checks if the cat's attempted move is valid
  
      @param r row of the destination
      @param c column of the destination
      @param b Board the game is on
      
      @return true if destination is valid for cat piece, otherwise return false
  */
	public boolean isValidMove(int r, int c, Board b) {
		int rowDistance = Math.abs(r - currR);
		int colDistance = Math.abs(c - currC);
		
		// checks if player is only moving at a distance of 1 space
		if ((rowDistance == 0 && colDistance == 1) || (rowDistance == 1 && colDistance == 0)) {
			// checks if there is no piece at the destination
			if (b.getSpace(r, c).getPiece() == null) {
				if (b.isWater(r, c))
					return canWalkWater(r, c, b);
				else if (b.isDen(r, c)) {
					if (COLOR.equalsIgnoreCase(b.denColor(c)))
						return false;
					return true;
				}
				return true; // empty space or trap
			}
			else {
				  if (b.isWater(r, c))
					  return canWalkWater(r, c, b);
				  return canCapture(r, c, b);
			}
		}
		return false;
	}
  
}