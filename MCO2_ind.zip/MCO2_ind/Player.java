/** This class represents the player of the game. */

public class Player { 

  /** This constructor initializes the player's color, the location of their den, and the whether it's their turn
   
      @param color the color of the pieces the player has
      @param turn whether if its the player's turn
  */
  public Player(String color, boolean turn){
    COLOR = color;
    
    if ("red".equalsIgnoreCase(COLOR))
        OWNDENC = 0;
    else
        OWNDENC = 8;
    
    isTurn = turn;
    pieces = new Piece[8];
  }

  /** This method returns the position or column value of the player's den
    
      @return the column of the player's den location
   */
  public int getDenC(){
    return OWNDENC; 
  }

  /** This method returns the color of the player's pieces 
   
      @return the color of the player's pieces
   */
  public String getColor(){
    return COLOR;
  }
 
  /** This method returns if it is already the player's turn already
    
      @return true if it is the player's turn, otherwise false
   */
  public boolean getIsTurn(){
    return isTurn;
  }
  
  /** This method updates isTurn which is the basis of if it is the player's turn
   
    @param turn the boolean if it is the player's turn
   */
  public void setIsTurn(boolean turn){
    isTurn = turn;
  }
  
  /** This method checks if player still has pieces that are not captured
    
      @return true if the player has no more pieces, otherwise false
   */
  public boolean isNoPieces() {
	  int count = 0;
	  for(int i = 0; i < pieces.length; i++){
	    if(pieces[i].getIsCaptured() == false)
	      count++; //counts pieces player has that is not captured
	  }
	  if (count > 0)   
	    return false;
	  else 
	    return true; 
	}
  
  /** This method checks if the player has already won the game

      @param playerCol the column or x-coordinate the player will go to
      @param playerRow the row or y-coordinate the player will go to
      @param obj represents the opposing player
    
      @return true if the player has won the game, otherwise  false
  */
  public boolean isWinner(int playerCol, int playerRow, Object obj){
	    Player opp = (Player) obj;
	    if (playerCol == opp.getDenC() && playerRow == 3) {
	    	return true; // if player is in opponent's den
	    }
	    //else if (opp.isNoPieces()) 
       // return true; //enemy has no more pieces
		else
			return (opp.isNoPieces()); //checks is the opponent has no more pieces
	  }


  /** This method sets the pieces on the board to be  the pieces the player will use 

      @param board the board the pieces are on
  */
  public void savePieces(Board board){
    if ("blue".equalsIgnoreCase(COLOR)){  
    	pieces[0] = board.getSpace(0, 6).getPiece(); // mouse
    	pieces[1] = board.getSpace(5, 7).getPiece(); // cat
    	pieces[2] = board.getSpace(4, 6).getPiece(); // wolf
    	pieces[3] = board.getSpace(1, 7).getPiece(); // dog
    	pieces[4] = board.getSpace(2, 6).getPiece(); // leopard
    	pieces[5] = board.getSpace(6, 8).getPiece(); // tiger
    	pieces[6] = board.getSpace(0, 8).getPiece(); // lion
    	pieces[7] = board.getSpace(6, 6).getPiece(); // elephant
    }
    else {
	   pieces[0] = board.getSpace(6, 2).getPiece();
	   pieces[1] = board.getSpace(1, 1).getPiece();
	   pieces[2] = board.getSpace(2, 2).getPiece();
	   pieces[3] = board.getSpace(5, 1).getPiece();
	   pieces[4] = board.getSpace(4, 2).getPiece();
	   pieces[5] = board.getSpace(0, 0).getPiece();
	   pieces[6] = board.getSpace(6, 0).getPiece();
	   pieces[7] = board.getSpace(0, 2).getPiece();
    }
  }

  /** Pieces the player owns */
  private Piece[] pieces;
  /** The column of the player's own den */
  private final int OWNDENC; 
  /** The value that dictates if it is the player's turn */
  private boolean isTurn;
  /** The colors of the player's pieces */
  private final String  COLOR;
}