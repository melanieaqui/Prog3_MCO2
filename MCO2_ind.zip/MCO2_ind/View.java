import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** This class represents the interface of the game. */
public class View extends JFrame{

	/** This is the constructor for the view class */
	public View(){
		super("Animal Chess");

		setLayout(new BorderLayout());
    
		initialize();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,600);
		setVisible(true);
	}
  
	/** This method initializes the components of the game GUI */
	public void initialize(){
		// north
		panelNorthA = new JPanel();
		panelNorthA.setLayout(new BorderLayout());
    
		btnAnimal = new JButton("Press to pick your animals");
		btnAnimal.setPreferredSize(new Dimension(200, 40));
		panelNorthA.add(btnAnimal, BorderLayout.NORTH);
    
		lblAnimal = new JLabel(" ", JLabel.CENTER);
		panelNorthA.add(lblAnimal, BorderLayout.CENTER);
    
		panelNorthB = new JPanel();
		panelNorthB.setLayout(new BorderLayout());

		lblColor = new JLabel(" ", JLabel.CENTER);
		panelNorthB.add(lblColor, BorderLayout.NORTH);
    
		btnRed = new JButton("RED");
		btnRed.setPreferredSize(new Dimension(250, 35));
		panelNorthB.add(btnRed, BorderLayout.WEST);
    
		btnBlue = new JButton("BLUE");
		btnBlue.setPreferredSize(new Dimension(250, 35));
		panelNorthB.add(btnBlue, BorderLayout.EAST);
    
		setColorEnabled(false);
    
		lblTurn = new JLabel(" ", JLabel.CENTER);
		panelNorthB.add(lblTurn, BorderLayout.SOUTH);
    
		panelNorthA.add(panelNorthB, BorderLayout.SOUTH);
		add(panelNorthA, BorderLayout.NORTH);
    
    
		// center
		panelCenter = new JPanel();
		panelCenter.setLayout(new GridLayout(7, 9));
    
		spaces = new JButton[7][9];
    
		boardLayout();
    
		add(panelCenter, BorderLayout.CENTER);

		// south
		panelSouth = new JPanel();
		panelSouth.setLayout(new BorderLayout());
		
		lblMove = new JLabel(" ", JLabel.CENTER);
		panelSouth.add(lblMove, BorderLayout.NORTH);
    
		lblResult = new JLabel(" ", JLabel.CENTER);
		panelSouth.add(lblResult, BorderLayout.CENTER);
    
		add(panelSouth, BorderLayout.SOUTH);
    
	}

  /** This method sets action listeners for the buttons

		  @param listener ActionListener of the buttons
  */
	public void setActionListeners(ActionListener listener){
		btnAnimal.addActionListener(listener);
		btnRed.addActionListener(listener);
		btnBlue.addActionListener(listener);

		for (int i = 0; i < 7; i++){
			for (int j = 0; j < 9; j++)
				spaces[i][j].addActionListener(listener);
		}
	}

	/** This method sets if the button for picking random animal is enabled

		  @param bEnabled boolean value of whether the button shoukd be enabled
	*/
	public void setAnimalEnabled(boolean bEnabled){
		btnAnimal.setEnabled(bEnabled);
	}

	/** This method sets if the button for choosing animals is enabled

		  @param bEnabled boolean value of whether the button should be enabled
	*/
	public void setColorEnabled(boolean bEnabled){
		btnRed.setEnabled(bEnabled);
		btnBlue.setEnabled(bEnabled);
	}

	/** This method sets if the buttons representing the spaces of the board should be enabled

		  @param bEnabled boolean representing if the button will be enabled
	*/
	public void setSpaceEnabled(boolean bEnabled){
		int i, j;
		for (i = 0; i < 7; i++){
			for (j = 0; j < 9; j++){
				spaces[i][j].setEnabled(bEnabled);
			}
		}
	}

	/** This method sets the text of lblAnimal 

		  @param animal the result of the picking of animals
  */
	public void setAnimalLbl(String animal){
		lblAnimal.setText(animal);
	}

	/** This method sets the text asking the player to choose color

	    @param no player number of the player who goes first
  */
	public void setColorLbl(int no){
		lblColor.setText("Player " + no + " choose your color");
	}

	/** This method sets text displaying whose turn it is 

      @param color of the player's turn
  */
	public void setTurnLbl(String color){
		if	(color != null)
			lblTurn.setText(color + " Player's Turn");
		else 
			lblTurn.setText("GAME OVER");
	}

	/** This method sets text of lblMove

		  @param move the action of the current player
  */
	public void setMoveLbl(String move){
		lblMove.setText(move);
	}

	/** This method sets text displaying the winner

      @param color of the winner
  */
	public void setResultLbl(String color){
		lblResult.setText(color + " WINS!");
	}

	/** This method returns the button in the board 

      @param r row of the button to be returned
      @param c column of the button to be returned

      @return button at given row and column
  */
	public JButton getSpace(int r, int c) {
		return spaces[r][c];
	}

  /** This method sets up the layout of the board buttons */
	public void boardLayout(){
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 9; j++) {
			   spaces[i][j] = new JButton();
			   
			   if (i == 3 && j == 0) {
				   spaces[i][j].setBackground(clrRed);
				   spaces[i][j].setOpaque(true);
			   }
			   else if (i == 3 && j == 8) {
				   spaces[i][j].setBackground(clrBlue);
				   spaces[i][j].setOpaque(true);
			   }
			   else if (i == 3 && j == 8) {
				   spaces[i][j].setBackground(clrBlue);
				   spaces[i][j].setOpaque(true);
			   }
			   else if ((i == 2 && j == 0) || (i == 2 && j == 8) || (i == 4 && j == 0) || (i == 4 && j == 8)) {
				   spaces[i][j].setBackground(clrBlack);
				   spaces[i][j].setOpaque(true);
			   }
			   else if (i == 3 && (j == 1 || j == 7)) {
				   spaces[i][j].setBackground(clrBlack);
				   spaces[i][j].setOpaque(true);
			   }
			   else if ((i == 1 || i == 2) && (j >= 3 && j <= 5)) {
				   spaces[i][j].setBackground(clrCyan);
				   spaces[i][j].setOpaque(true);
			   }
			   else if ((i == 4 || i == 5) && (j >= 3 && j <= 5)) {
				   spaces[i][j].setBackground(clrCyan);
				   spaces[i][j].setOpaque(true);
			   }
			   else {
				   spaces[i][j].setBackground(clrGreen);
				   spaces[i][j].setOpaque(true);
			   }
			   
			   
			   panelCenter.add(spaces[i][j]);
	    	}
	    }
		
		// place red animal icons
		spaces[6][2].setIcon(rMouse);
		spaces[1][1].setIcon(rCat);
		spaces[2][2].setIcon(rWolf);
		spaces[5][1].setIcon(rDog);
		spaces[4][2].setIcon(rLeopard);
		spaces[0][0].setIcon(rTiger);
		spaces[6][0].setIcon(rLion);
		spaces[0][2].setIcon(rElephant);
		
		// place blue animal icons
		spaces[0][6].setIcon(bMouse);
		spaces[5][7].setIcon(bCat);
		spaces[4][6].setIcon(bWolf);
		spaces[1][7].setIcon(bDog);
		spaces[2][6].setIcon(bLeopard);
		spaces[6][8].setIcon(bTiger);
		spaces[0][8].setIcon(bLion);
		spaces[6][6].setIcon(bElephant);
					    
	  setSpaceEnabled(false);
	}

  /** This method moves the icon

      @param fromR the current row of the icon
      @param fromC the current column of the icon
      @param toR the destination row of the icon
      @param toC the destination column of the icon
  */
	public void moveIcon(int fromR, int fromC, int toR, int toC) {	  
		spaces[toR][toC].setIcon(spaces[fromR][fromC].getIcon());
		spaces[fromR][fromC].setIcon(null);
	}

	/** contains pre-game and turn*/
  private JPanel panelNorthA; 
  /** contains pre-game and turn*/
	private JPanel panelNorthB; 
  /** contains the board */
	private JPanel panelCenter; 
  /** contains result*/
	private JPanel panelSouth; 
  
  /**the label animal that was chosen from pickStart()*/
	private JLabel lblAnimal;
  /**label prompting player to choose a color*/
	private JLabel lblColor;
  /**label displaying who's turn it is*/
	private JLabel lblTurn;
  /**label displaying what the current player is doing*/
	private JLabel lblMove;
  /**label displaying the result of the game*/
	private JLabel lblResult;

  /**Button that starts randomizing animals at start of game*/
	private JButton btnAnimal;
  /**Button that chooses red as the first player's color*/
	private JButton btnRed;
  /**Button that chooses blue as the first player's color*/
	private JButton btnBlue;
  /**Array of buttons representing the spaces on the board*/
	private JButton[][] spaces;

  /**the green color*/
	private Color clrGreen = Color.GREEN;
  /**the cyan color*/
	private Color clrCyan = Color.CYAN;
  /**the black color*/
	private Color clrBlack = Color.BLACK;
  /**the red color*/
	private Color clrRed = Color.RED;
  /**the blue color*/
	private Color clrBlue = Color.BLUE;

  /**Icon for the red mouse piece*/
	private ImageIcon rMouse = new ImageIcon("r1.jpg");
  /**Icon for the red cat piece*/
	private ImageIcon rCat = new ImageIcon("r2.jpg");
  /**Icon for the red wolf piece*/
	private ImageIcon rWolf = new ImageIcon("r3.jpg");
  /**Icon for the red dog piece*/
	private ImageIcon rDog = new ImageIcon("r4.jpg");
  /**Icon for the red leopard piece*/
	private ImageIcon rLeopard = new ImageIcon("r5.jpg");
  /**Icon for the red tiger piece*/
	private ImageIcon rTiger = new ImageIcon("r6.jpg");
  /**Icon for the red lion piece*/
	private ImageIcon rLion = new ImageIcon("r7.jpg");
  /**Icon for the red elephant piece*/
	private ImageIcon rElephant = new ImageIcon("r8.jpg");
	
  /**Icon for the blue mouse piece*/
	private ImageIcon bMouse = new ImageIcon("b1.jpg");
  /**Icon for the blue cat piece*/
	private ImageIcon bCat = new ImageIcon("b2.jpg");
  /**Icon for the blue wolf piece */
	private ImageIcon bWolf = new ImageIcon("b3.jpg");
  /**Icon for the blue dog piece*/
	private ImageIcon bDog = new ImageIcon("b4.jpg");
  /**Icon for the blue leopard piece*/
	private ImageIcon bLeopard = new ImageIcon("b5.jpg");
  /**Icon for the blue tiger piece*/
	private ImageIcon bTiger = new ImageIcon("b6.jpg");
  /**Icon for the blue lion piece*/
	private ImageIcon bLion = new ImageIcon("b7.jpg");
  /**Icon for the blue elephant piece*/
	private ImageIcon bElephant = new ImageIcon("b8.jpg");

  // citation for icons
  // Jungle game. (n.d.). [Illustration]. http://ancientchess.com/page/play-doushouqi.htm
}